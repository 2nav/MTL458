echo "This is a script"
