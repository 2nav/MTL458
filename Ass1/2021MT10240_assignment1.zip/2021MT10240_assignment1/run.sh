gcc 2021MT10240_shell.c -o shell
./shell