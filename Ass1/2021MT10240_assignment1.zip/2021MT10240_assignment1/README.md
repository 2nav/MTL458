Run shell from this directory or please comment out line 190(approx) -
`strcat(HOME1, "/home/user"); // assuming shell is run from the submission directory, adding /home/user to the path` to run from /home/user directory.

